package com.example.sqltask;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private  Button createDbBtn,addValuesBtn,getValuesBtn;
    private SqlLiteClass objectsqlLiteClass;

    private ArrayList<DbModelClass> objectarrayList;
    private TextView getValuesTv;
    private EditText nameET,locationET;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        connectXML();
    }

    private void connectXML(){
        try
        {
            createDbBtn=findViewById(R.id.createDbBtn);
            objectsqlLiteClass=new SqlLiteClass(this);

            nameET=findViewById(R.id.nameET);
            locationET=findViewById(R.id.locationET);

            objectarrayList=new ArrayList<>();
            getValuesBtn=findViewById(R.id.getValueBtn);
            getValuesTv=findViewById(R.id.valueTV);
            addValuesBtn=findViewById(R.id.addValuesBtn);
            createDbBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    createDb();
                }
            });

            addValuesBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    AddValuesToDatabase();
                }
            });
            getValuesBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    getValuesFromDb();
                }
            });


        }catch (Exception e){
            Toast.makeText(this,"connectXML"+e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }
    private void createDb(){
        try
        {
            objectsqlLiteClass.getReadableDatabase();


        }catch (Exception e){
            Toast.makeText(this,"createDb"+e.getMessage(),Toast.LENGTH_SHORT).show();

        }
    }


    private void AddValuesToDatabase(){
        try
        {
            if(!nameET.getText().toString().isEmpty() && !locationET.getText().toString().isEmpty())
            {
                SQLiteDatabase objectSqLiteDatabase =objectsqlLiteClass.getWritableDatabase();
                if(objectSqLiteDatabase!=null)
                {
                    ContentValues objectContentValues=new ContentValues();
                    objectContentValues.put("Name",nameET.getText().toString());
                    objectContentValues.put("Location",locationET.getText().toString());
                   long check=objectSqLiteDatabase.insert("classtable",null,objectContentValues);
                   if(check!=-1)
                   {
                       Toast.makeText(this,"values inserted",Toast.LENGTH_SHORT).show();
                       nameET.setText(null);
                       locationET.setText(null);
                       nameET.requestFocus();
                   }else
                       {
                           Toast.makeText(this,"fails to add values inserted",Toast.LENGTH_SHORT).show();

                   }

                }else
                    {
                    Toast.makeText(this,"database object is null",Toast.LENGTH_SHORT).show();
                }

            }else if(nameET.getText().toString().isEmpty())
            {
                Toast.makeText(this,"enter the name",Toast.LENGTH_SHORT).show();
                nameET.requestFocus();

            }else if(locationET.getText().toString().isEmpty())
            {
                Toast.makeText(this,"enter the location",Toast.LENGTH_SHORT).show();
                locationET.requestFocus();

            }

        }catch (Exception e){

            Toast.makeText(this,"AddValuesToDatabase"+e.getMessage(),Toast.LENGTH_SHORT).show();
        }
    }

    private void getValuesFromDb(){
        try
        {
            SQLiteDatabase objectsqLiteDatabase=objectsqlLiteClass.getReadableDatabase();
            if(objectsqLiteDatabase!=null){
                Cursor objectcursor =objectsqLiteDatabase.rawQuery("select * from classtable",null);
                StringBuffer objectstringBuffer=new StringBuffer();


                if(objectcursor.getCount()!=0)
                {
                    while (objectcursor.moveToNext())
                    {
                        DbModelClass objectdbModelClass=new DbModelClass();
                        objectdbModelClass.setName(objectcursor.getString(0));
                        objectdbModelClass.setLocation(objectcursor.getString(1));
                        objectarrayList.add(objectdbModelClass);
//                        objectstringBuffer.append("Name"+objectcursor.getString(0)+"\n");
//                        objectstringBuffer.append("Location"+objectcursor.getString(1)+"\n");



                    }
                    getValuesTv.setText(objectstringBuffer);


                }else
                    {
                    Toast.makeText(this,"no values",Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(this,"getValuesFromDb is null",Toast.LENGTH_SHORT).show();

            }


        }catch (Exception e){
            Toast.makeText(this,"getValuesFromDb"+e.getMessage(),Toast.LENGTH_SHORT).show();

        }
    }

}
